import umap
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from pretrain import set_seed


#min_dist=0.3,
set_seed(seed=42)
umap_model = umap.UMAP(n_neighbors=15,random_state=42,min_dist=0.6)
# 读取CSV文件
encoded_data = pd.read_csv('/qilihua/1177/scMDC-master-distiller1.6/scMDC-master-distiller1.6/src/results/1_embedding1.csv', header=None)
cluster_labels = pd.read_csv('/qilihua/1177/scMDC-master-distiller1.6/scMDC-master-distiller1.6/src/results/1_pred1.csv', header=None)
unique_labels = np.unique(cluster_labels.astype(int))

# 对编码结果进行UMAP转换
umap_data = umap_model.fit_transform(encoded_data)
fig, ax = plt.subplots()

# 使用Matplotlib绘制UMAP转换结果的散点图
for label in unique_labels:
    # 提取属于当前簇的数据点的索引
    indices = np.where(cluster_labels == label)[0]

    # 获取属于当前簇的数据点的UMAP坐标
    cluster_points = umap_data[indices, :]

    # 使用不同的颜色标记当前簇的数据点
    ax.scatter(cluster_points[:, 0], cluster_points[:, 1], label=f'Cluster {label}',s=3)
ax.set_xlabel('UMAP Dimension 1')
ax.set_ylabel('UMAP Dimension 2')
ax.set_title('UMAP Visualization with Cluster Colors')

# 显示图例，并将图例放置在右上角的位置
ax.legend(bbox_to_anchor=(1.02, 1), loc='upper left')
x_min, x_max = np.min(umap_data[:, 0]), np.max(umap_data[:, 0])
y_min, y_max = np.min(umap_data[:, 1]), np.max(umap_data[:, 1])
x_margin = (x_max - x_min) * 0.1
y_margin = (y_max - y_min) * 0.1
plt.xlim(x_min - x_margin, x_max + x_margin)
plt.ylim(y_min - y_margin, y_max + y_margin)
# 调整子图布局以缩小UMAP结果的整体尺寸
plt.tight_layout()
# 保存为图片
plt.savefig('umap_visualization.png')
plt.show()
plt.close()